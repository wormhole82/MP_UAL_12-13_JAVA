package org.mp.exceptions;

// TODO: Auto-generated Javadoc
/**
 * The Class EmptyStackException.
 */
public class EmptyStackException extends Exception
{
    
    /**
     * Constructor para la excepcion.
     *
     * @param error the error
     */
    public EmptyStackException(String error)
    {
        super( error );
    }
}
