package org.mp.sesion05;

// TODO: Auto-generated Javadoc
/**
 * The Class EmptyStackException.
 */
public class EmptyStackException extends Exception
{
    
    /**
     * Constructor para la excepcion.
     *
     * @param error the error
     */
    public EmptyStackException(String error)
    {
        super( error );
    }
}
