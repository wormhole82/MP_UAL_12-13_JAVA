package org.mp.sesion05;

// TODO: Auto-generated Javadoc
/**
 * The Class EmptyQueueException.
 */
public class EmptyQueueException extends Exception
{
    
    /**
     * Constructor para la excepcion.
     *
     * @param error the error
     */
    public EmptyQueueException(String error)
    {
        super( error );
    }
}
