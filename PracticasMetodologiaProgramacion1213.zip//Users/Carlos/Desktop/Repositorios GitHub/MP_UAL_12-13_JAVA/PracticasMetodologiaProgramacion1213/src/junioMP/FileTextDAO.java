package junioMP;

public interface FileTextDAO {

	void anadir(Object o);
	
	Object buscar(Object o);
	
	boolean eliminar(Object o);
	
	boolean modificar(Object o);
		
	
}
