package org.mp.sesion03;

// TODO: Auto-generated Javadoc
/**
 * The Class Socio.
 */
public class Socio {

	/** The nombre. */
	String nombre;

	/**
	 * Instantiates a new socio.
	 *
	 * @param nombre the nombre
	 */
	public Socio(String nombre) {
		this.nombre = nombre;
	}

}
