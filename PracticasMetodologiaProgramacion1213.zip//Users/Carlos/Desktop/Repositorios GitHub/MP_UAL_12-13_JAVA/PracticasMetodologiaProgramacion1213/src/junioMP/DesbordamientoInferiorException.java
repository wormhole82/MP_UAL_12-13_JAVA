package junioMP;

public class DesbordamientoInferiorException extends Exception {


	public DesbordamientoInferiorException(String message) {
		super(message);
	}

}
