package org.mp.sesion08;

public class XYFueraImagenException extends Exception {


	public XYFueraImagenException(String message) {
		super(message);
	}

}
